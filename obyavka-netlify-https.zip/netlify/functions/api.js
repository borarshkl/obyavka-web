// Netlify serverless proxy for the original Obyavka API.
// The upstream host is fixed here; callers cannot supply an arbitrary URL.
const UPSTREAM = "http://139.100.236.142";
const ALLOWED_PREFIX = "/api/";

exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: {
      ...headers,
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, X-App-Version",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
    }, body: "" };
  }

  try {
    const path = event.queryStringParameters?.path || "";
    if (!path.startsWith(ALLOWED_PREFIX) || path.includes("..") || path.includes("://")) {
      return { statusCode: 400, headers, body: JSON.stringify({ok:false,error:"Недопустимый API-путь"}) };
    }
    const method = event.httpMethod;
    if (!["GET", "POST"].includes(method)) {
      return { statusCode: 405, headers, body: JSON.stringify({ok:false,error:"Метод не поддерживается"}) };
    }

    const forwardHeaders = {
      "X-App-Version": event.headers["x-app-version"] || event.headers["X-App-Version"] || "0"
    };
    const auth = event.headers.authorization || event.headers.Authorization;
    if (auth) forwardHeaders.Authorization = auth;
    const contentType = event.headers["content-type"] || event.headers["Content-Type"];
    if (contentType) forwardHeaders["Content-Type"] = contentType;

    const response = await fetch(UPSTREAM + path, {
      method,
      headers: forwardHeaders,
      body: method === "POST" ? (event.body || "{}") : undefined,
      redirect: "manual"
    });
    const body = await response.text();
    return {
      statusCode: response.status,
      headers,
      body: body || JSON.stringify({ok:false,error:"Пустой ответ игрового сервера"})
    };
  } catch (err) {
    return {
      statusCode: 502,
      headers,
      body: JSON.stringify({
        ok: false,
        error: "Не удалось связаться с игровым сервером. Возможно, сервер недоступен."
      })
    };
  }
};
