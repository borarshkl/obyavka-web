// API details recovered from the Android package.
const API_BASE = "/.netlify/functions/api?path=";
const APP_VERSION = "0";
const $ = (id) => document.getElementById(id);
let token = localStorage.getItem("obyavka_token") || "";
let state = null;

async function api(path, {method="GET", body=null, auth=true}={}) {
  const headers = {"X-App-Version": APP_VERSION};
  if (body !== null) headers["Content-Type"] = "application/json";
  if (auth && token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(API_BASE + encodeURIComponent(path), {
    method, headers, body: body === null ? undefined : JSON.stringify(body)
  });
  const data = await response.json();
  if (!response.ok || !data.ok) throw new Error(data.error || `Ошибка сервера (${response.status})`);
  return data;
}

function showLogin(message="") {
  $("login").hidden = false;
  $("dashboard").hidden = true;
  $("loginError").textContent = message;
  $("connection").textContent = "Не подключено";
}
function showDashboard(data) {
  state = data.state || data;
  $("login").hidden = true;
  $("dashboard").hidden = false;
  $("connection").textContent = "На связи";
  $("welcomeName").textContent = state.nick || "Игрок";
  $("balance").textContent = `${Math.floor(Number(state.balance || 0)).toLocaleString("ru-RU")} ₽`;
  $("phoneCount").textContent = (state.phones || []).length;
  $("partsCount").textContent = Object.values(state.parts || {}).reduce((a,v)=>a+(Number(v)||0),0);
  $("padCount").textContent = (state.pads || []).length;
}
$("loginForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const nick = $("nick").value.trim(), pw = $("password").value;
  $("loginError").textContent = "Подключаемся…";
  try {
    const data = await api("/api/login", {method:"POST", body:{nick, pw}, auth:false});
    token = data.token;
    localStorage.setItem("obyavka_token", token);
    showDashboard(data);
  } catch (e) {
    showLogin(e.message.includes("Failed to fetch") ? "Браузер не смог связаться с сервером. Возможно, сервер блокирует браузерные запросы (CORS) или доступен только по HTTP." : e.message);
  }
});
$("logout").addEventListener("click", () => {
  token = ""; state = null; localStorage.removeItem("obyavka_token"); showLogin();
});
document.querySelectorAll(".tab").forEach(btn => btn.addEventListener("click", () => {
  document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===btn));
  const labels={buy:"Закупка",ali:"Алиэкспресс",shop:"Инвентарь",ads:"Объявления",prof:"Профиль"};
  $("tabContent").innerHTML=`<h2>${labels[btn.dataset.tab]}</h2><p class="muted">Этот раздел найден в исходном приложении. Его интерфейс и действия будут перенесены на следующем этапе.</p>`;
}));
async function restore() {
  if (!token) return;
  try { showDashboard(await api("/api/state")); }
  catch(e) { token=""; localStorage.removeItem("obyavka_token"); showLogin("Сессия не восстановлена: "+e.message); }
}
restore();